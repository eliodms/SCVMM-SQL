
# Variables
$ScriptDir = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
. (Join-Path $ScriptDir "Functions.ps1")

Start-Transcript -Path "$ScriptDir\$Env:COMPUTERNAME.log"

##### Change below variables as required #####

$SetupExe = "\\fs01.corp.demolab.com\Share\Sources\SQL-2025\setup.exe"
$logdir = "\\fs01\VMMlibrary\Logs"

##### Change above variables as required #####

$HostName = $env:COMPUTERNAME
$timestampFolder = Get-Date -Format "yyyyMMdd" # Add "-HHmmss" for mre detail
$logSubFolder = Join-Path -Path $logdir -ChildPath "$HostName-$timestampFolder"
$logFilePath = Join-Path -Path $logSubFolder -ChildPath "Install-SQL.log"

$RedirectSQLStandardOutput = Join-Path -Path $logSubFolder -ChildPath "SQLStandardOutput.log"
$RedirectSQLStandardError = Join-Path -Path $logSubFolder -ChildPath "SQLStandardError.log"

# Path to the CSV file
$CsvPath = Join-Path $ScriptDir "ListOfSQLServers.csv"
$ConfigFile = Join-Path $ScriptDir "SQLServer2025_Config.ini"

# Import CSV and find matching record
$ServerRecord = Import-Csv -Path $CsvPath | Where-Object { $PSItem.ComputerName -eq $HostName }

# Gets gMSA from CSV and update INI file accordingly, same for SQLSYSADMINACCOUNTS
(Get-Content -Path $ConfigFile -Raw) -replace [regex]::Escape('<gMSA-Account>'), [string]$ServerRecord.SQLAccount | Set-Content -Path $ConfigFile -Encoding UTF8
(Get-Content -Path $ConfigFile -Raw) -replace [regex]::Escape('<SQLSYSADMINACCOUNTS>'), [string]$ServerRecord.SQLSYSADMINACCOUNTS | Set-Content -Path $ConfigFile -Encoding UTF8

###################################################
# Run AssignLetters.ps1 and wait for it to finish #
###################################################
Write-Log -Message "Calling Assign-Letters.ps1"
$AssignScript = Join-Path $ScriptDir "Assign-Letters.ps1"
& $AssignScript

###################################################
# Install SQL Core                                #
###################################################
Write-Log -Message "Calling Install-SQL-Core.ps1"
$AssignScript = Join-Path $ScriptDir "Install-SQL-Core.ps1"
& $AssignScript

###################################################
# Install SQL always ON                           #
###################################################
Write-Log -Message "Calling Install-Always-On.ps1"


if ($null -eq $ServerRecord) {
    Write-Log -Message "No matching record found for $HostName in $CsvPath. Exiting..."
    exit 1
}

# Path to the Always-On script
$AssignScript = Join-Path $ScriptDir "Install-Always-On.ps1"

# Call the script with parameters from CSV
& $AssignScript `
    -WSFC_Name $ServerRecord.WSFC_Name `
    -WSFC_IP $ServerRecord.WSFC_IP `
    -PrimarySQLName $ServerRecord.PrimarySQLName `
    -SecondarySQLName $ServerRecord.SecondarySQLName `
    -DBName $ServerRecord.DBName `
    -BackupPath $ServerRecord.BackupPath `
    -AG_Name $ServerRecord.AG_Name `
    -ListenerName $ServerRecord.ListenerName `
    -ListenerIP $ServerRecord.ListenerIP `
    -ListenerSM $ServerRecord.ListenerSM `
    -ListenerPort $ServerRecord.ListenerPort `
    -SQLAccount $ServerRecord.SQLAccount

# Get all IPv4 addresses and their adapter names
$IPv4Info = Get-NetIPAddress -AddressFamily IPv4 `
            | Where-Object { $_.IPAddress -notlike '169.*' -and $_.IPAddress -ne '127.0.0.1' } `
            | ForEach-Object {
                [PSCustomObject]@{
                    AdapterName = (Get-NetAdapter -InterfaceIndex $_.InterfaceIndex).Name
                    IPAddress   = $_.IPAddress
                }
            }

# Log each adapter and IP address
foreach ($item in $IPv4Info) { Write-Log -Message "Adapter: $($item.AdapterName) | IPv4: $($item.IPAddress)" }

Write-Log -Message "End of Install-SQL.ps1 script attained."
Write-Log -Message "Copying contents from '$ScriptDir' to '$logSubFolder'..."
# Copy all items inside $ScriptDir into $logSubFolder
Copy-Item -Path (Join-Path $ScriptDir '*.log') -Destination $logSubFolder -Force -ErrorAction Stop


Stop-Transcript
